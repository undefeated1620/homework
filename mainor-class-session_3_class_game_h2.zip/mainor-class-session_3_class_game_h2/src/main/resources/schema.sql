CREATE TABLE guessing_game (
    id INTEGER PRIMARY KEY,
    correct_answer INTEGER,
    name VARCHAR
);