INSERT INTO guessing_game (id,
                           correct_answer,
                           name)
VALUES (1, 2, 'GAME1');