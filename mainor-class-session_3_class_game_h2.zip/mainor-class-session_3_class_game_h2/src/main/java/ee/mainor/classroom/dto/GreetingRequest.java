package ee.mainor.classroom.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GreetingRequest {

    private String firstname;
    private String lastname;


}
