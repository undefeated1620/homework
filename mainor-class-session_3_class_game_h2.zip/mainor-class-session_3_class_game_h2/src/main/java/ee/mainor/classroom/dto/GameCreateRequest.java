package ee.mainor.classroom.dto;

import lombok.Data;

@Data
public class GameCreateRequest {

    private Integer correctAnswer;

}
